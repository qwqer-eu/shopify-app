<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\ShippingController;

use App\Http\Controllers\OrderController;

use App\Http\Controllers\SettingsController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
})->middleware(['verify.shopify'])->name('home');

Route::post('create-carrier', [ShippingController::class, 'add_shipping_carrier']);

Route::post('add-rates', [ShippingController::class, 'add_shipping_rates']);

// Order Creation Webhook Route

Route::post('create-order', [ShippingController::class, 'create_order']);

Route::get('get-orders', [OrderController::class, 'get_orders']);

Route::get('get-delivery-orders', [OrderController::class, 'get_delivery_orders']);

// Route::post('api-settings', [SettingsController::class, 'settings']);

Route::get('api-details', [SettingsController::class, 'get_details']);

Route::post('update-api-details', [SettingsController::class, 'update_details']);

