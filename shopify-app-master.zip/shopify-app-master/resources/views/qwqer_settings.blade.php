<div class="input-name">
        <input type = "hidden" id = "data_id" value = "" >
    <div class="field">
        <label>API Key</label>
        <input type = "text" id = "api_key" value = "" >
    </div>
    <div class="field">
        <label>Trading point id</label>
        <input type = "text" id = "trading_point_id" value = "" >
    </div>
    <div class="field">
        <label>Order Category</label>
        <select id="order_category"> 
                    <option value="Flowers">Flowers</option>
                    <option value="Food">Food</option>
                    <option value="Cake">Cake</option>
                    <option value="Present">Present</option>
                    <option value="Clothes">Clothes</option>
                    <option value="Document">Document</option>
                    <option value="Jewelry">Jewelry</option>
        </select>
    </div>      
    <div class="submit-button">
        <button id = 'submitBtn'>Update</button>
    </div>

</div>           