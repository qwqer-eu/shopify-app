    <table class="table" id="order">
        <thead>
            <tr>
                <th class="text-center">ID</th>
                <th class="text-center">Sr.No.</th>
                <th class="text-center">Order ID</th>
                <th class="text-center">Customer Name</th>
                <th class="text-center">Customer Email</th>
                <th class="text-center">Shipping Address</th>
                <th class="text-center">Billing Address</th>
            </tr>
            </thead>
        <tbody>
        </tbody>
    </table>