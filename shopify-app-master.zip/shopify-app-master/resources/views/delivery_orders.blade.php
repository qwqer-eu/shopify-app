    <table class="table" id="order_list">
        <thead>
            <tr>
                <th class="text-center">ID</th>
                <th class="text-center">Sr.No.</th>
                <th class="text-center">Order ID</th>
                <th class="text-center">Client Distance</th>
                <th class="text-center">Distance</th>
                <th class="text-center">Client Price</th>
                <th class="text-center">Status</th>
               <!--  <th class="text-center">Action</th> -->
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>